import { useEffect, useState } from "react";
import { NavLink, Navigate, Route, Routes } from "react-router-dom";
import { api } from "./api";
import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import Teachers from "./pages/Teachers";
import Accounts from "./pages/Accounts";
import Sessions from "./pages/Sessions";
import Stats from "./pages/Stats";
import Settings from "./pages/Settings";

export default function App() {
  const [user, setUser] = useState<{ username: string } | null | undefined>(undefined);

  useEffect(() => {
    api("/auth/me").then(setUser).catch(() => setUser(null));
    const h = () => setUser(null);
    window.addEventListener("unauthorized", h);
    return () => window.removeEventListener("unauthorized", h);
  }, []);

  if (user === undefined) return null;
  if (!user) return <Login onLogin={setUser} />;

  const logout = async () => {
    await api("/auth/logout", { method: "POST" });
    setUser(null);
  };

  return (
    <div className="layout">
      <aside className="side">
        <h1>🎥 Zoom Platform</h1>
        <nav>
          <NavLink to="/" end>Bosh sahifa</NavLink>
          <NavLink to="/teachers">O'qituvchilar</NavLink>
          <NavLink to="/accounts">Zoom akkauntlar</NavLink>
          <NavLink to="/sessions">Darslar tarixi</NavLink>
          <NavLink to="/stats">Statistika</NavLink>
          <NavLink to="/settings">Sozlamalar</NavLink>
        </nav>
        <div className="muted" style={{ padding: "0 8px" }}>
          {user.username}
          <div><button className="sm" onClick={logout} style={{ marginTop: 6 }}>Chiqish</button></div>
        </div>
      </aside>
      <main className="main">
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/teachers" element={<Teachers />} />
          <Route path="/accounts" element={<Accounts />} />
          <Route path="/sessions" element={<Sessions />} />
          <Route path="/stats" element={<Stats />} />
          <Route path="/settings" element={<Settings me={user.username} />} />
          <Route path="*" element={<Navigate to="/" />} />
        </Routes>
      </main>
    </div>
  );
}
