import { api, fmtMin, fmtTime } from "../api";
import { Blocks, Stat, useLoad } from "../ui";

export default function Dashboard() {
  const { data, error, reload } = useLoad<any>("/dashboard", 5000);
  if (!data) return <div className="muted">{error || "Yuklanmoqda…"}</div>;
  const c = data.capacity;

  const stop = async (id: number) => {
    if (!confirm("Darsni to'xtatasizmi?")) return;
    await api(`/sessions/${id}/stop`, { method: "POST" });
    reload();
  };

  return (
    <>
      <div className="page-head"><h2>Bosh sahifa</h2></div>
      {!data.bot_running && <div className="card err">Telegram bot ishlamayapti: .env da BOT_TOKEN ko'rsatilmagan.</div>}
      <div className="grid">
        <Stat label="Faol darslar" value={data.active_sessions.length} />
        <Stat label="Bo'sh akkauntlar" value={`${c.free} / ${c.total}`} sub={`band: ${c.busy}, xatoli: ${c.total - c.healthy}`} />
        <Stat label="Bugun" value={`${data.today.sessions} dars`} sub={fmtMin(data.today.actual_minutes)} />
        <Stat label="Shu oy" value={`${data.month.sessions} dars`} sub={fmtMin(data.month.actual_minutes)} />
        <Stat label="Faol o'qituvchilar" value={data.teachers} />
      </div>
      <div className="card">
        <h3 style={{ marginTop: 0 }}>Hozir o'tayotgan darslar</h3>
        {data.active_sessions.length === 0 ? <div className="empty">Hozir faol dars yo'q</div> : (
          <div className="table-wrap"><table>
            <thead><tr><th>O'qituvchi</th><th>Boshlangan</th><th>Tugashi</th><th>Bloklar</th><th></th></tr></thead>
            <tbody>
              {data.active_sessions.map((s: any) => (
                <tr key={s.id}>
                  <td>{s.teacher}</td>
                  <td>{fmtTime(s.started_at)}</td>
                  <td>{fmtTime(new Date(new Date(s.started_at).getTime() + s.planned_minutes * 60000).toISOString())}</td>
                  <td><Blocks blocks={s.blocks} /></td>
                  <td><button className="sm danger" onClick={() => stop(s.id)}>To'xtatish</button></td>
                </tr>
              ))}
            </tbody>
          </table></div>
        )}
      </div>
    </>
  );
}
