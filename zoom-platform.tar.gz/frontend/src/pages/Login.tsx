import { FormEvent, useState } from "react";
import { api } from "../api";

export default function Login({ onLogin }: { onLogin: (u: any) => void }) {
  const [username, setU] = useState("");
  const [password, setP] = useState("");
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setBusy(true);
    try {
      onLogin(await api("/auth/login", { method: "POST", body: { username, password } }));
    } catch (e: any) {
      setErr(e.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <form className="card login" onSubmit={submit}>
      <h2 style={{ marginTop: 0 }}>🎥 Zoom Platform</h2>
      <label>Login</label>
      <input value={username} onChange={(e) => setU(e.target.value)} autoFocus autoComplete="username" />
      <label>Parol</label>
      <input type="password" value={password} onChange={(e) => setP(e.target.value)} autoComplete="current-password" />
      {err && <div className="err">{err}</div>}
      <button className="primary" style={{ marginTop: 14, width: "100%" }} disabled={busy || !username || !password}>
        Kirish
      </button>
    </form>
  );
}
