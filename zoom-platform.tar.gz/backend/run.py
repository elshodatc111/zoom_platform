"""Ishga tushirish: python run.py"""
import asyncio
import sys

import uvicorn

from app.core.config import get_settings

if __name__ == "__main__":
    if sys.platform == "win32":
        asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
    s = get_settings()
    uvicorn.run("app.main:app", host=s.host, port=s.port, log_level="info")
